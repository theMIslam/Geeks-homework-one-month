package kg.geektech.game.players;

public interface HavingSuperAbility {
    void applySuperPower(Hero[] heroes, Boss boss);
}
